require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const monitoringService = require('./services/monitoringService');
const emailService = require('./services/emailService');
const logService = require('./services/logService');
const systemMonitoringService = require('./services/systemMonitoringService');
const emailConfigService = require('./services/emailConfigService');
const kubernetesService = require('./services/kubernetesService');
const urlMonitoringService = require('./services/urlMonitoringService');
const kubernetesConfigService = require('./services/kubernetesConfigService');
const thresholdService = require('./services/thresholdService');
const scriptService = require('./services/scriptService');



const app = express();
const PORT = 5001;

// Middleware
app.use(cors());
app.use(express.json());

// Import services
const userService = require('./services/userService');
const dbConfigService = require('./services/dbConfigService');
const realOracleService = require('./services/realOracleService');

// Basic route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Oracle Monitor API with Real Database Connection!',
    timestamp: new Date(),
    status: 'OK',
    userCount: userService.getUserCount(),
    dbConfigured: dbConfigService.getConfig().isConfigured
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date(),
    uptime: process.uptime(),
    userCount: userService.getUserCount(),
    dbConfigured: dbConfigService.getConfig().isConfigured
  });
});

// AUTH ROUTES
app.post('/api/auth/login', (req, res) => {
  try {
    const { username, password } = req.body;
    
    console.log(`🔐 Login attempt: ${username}`);
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const user = userService.authenticateUser(username, password);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(400).json({ 
      success: false,
      error: error.message 
    });
  }
});

// USER ROUTES (keeping existing user management)
app.get('/api/users', (req, res) => {
  try {
    const users = userService.getAllUsers();
    console.log(`📋 Fetched ${users.length} users`);
    res.json({ success: true, users });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/users', (req, res) => {
  try {
    const { username, password, firstName, lastName, email, role, status } = req.body;

    console.log('📝 Creating user:', { username, firstName, lastName, email, role, status });

    if (!username || !password || !firstName || !lastName || !email) {
      console.log('❌ Missing required fields');
      return res.status(400).json({ 
        success: false,
        error: 'Username, password, first name, last name, and email are required' 
      });
    }

    const userData = {
      username, password, firstName, lastName, email,
      role: role || 'user',
      status: status || 'active'
    };

    const newUser = userService.createUser(userData);
    console.log('✅ User created successfully:', newUser.username);
    
    res.status(201).json({ 
      success: true, 
      user: newUser,
      message: 'User created successfully' 
    });
  } catch (error) {
    console.error('❌ Create user error:', error.message);
    res.status(400).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.put('/api/users/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { username, password, firstName, lastName, email, role, status } = req.body;

    console.log('🔄 Updating user:', id, { username, firstName, lastName, email, role, status });

    const userData = { username, firstName, lastName, email, role, status };

    if (password && password.trim() !== '') {
      userData.password = password;
    }

    Object.keys(userData).forEach(key => 
      userData[key] === undefined && delete userData[key]
    );

    const updatedUser = userService.updateUser(id, userData);
    console.log('✅ User updated successfully:', updatedUser.username);
    
    res.json({ 
      success: true, 
      user: updatedUser,
      message: 'User updated successfully' 
    });
  } catch (error) {
    console.error('❌ Update user error:', error.message);
    res.status(400).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.delete('/api/users/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    console.log('🗑️ Deleting user:', id);
    
    userService.deleteUser(id);
    console.log('✅ User deleted successfully');
    
    res.json({ 
      success: true, 
      message: 'User deleted successfully' 
    });
  } catch (error) {
    console.error('❌ Delete user error:', error.message);
    res.status(400).json({ 
      success: false,
      error: error.message 
    });
  }
});

// DATABASE CONFIGURATION ROUTES
app.get('/api/database/config', (req, res) => {
  try {
    const config = dbConfigService.getPublicConfig();
    console.log('📊 Database config requested');
    res.json({ success: true, config });
  } catch (error) {
    console.error('❌ Get database config error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/database/config', (req, res) => {
  try {
    const { host, port, serviceName, username, password } = req.body;

    console.log('💾 Updating database config:', { host, port, serviceName, username });

    if (!host || !port || !serviceName || !username || !password) {
      return res.status(400).json({ 
        success: false,
        error: 'All database connection fields are required' 
      });
    }

    const configData = { host, port, serviceName, username, password };
    
    const saved = dbConfigService.updateConfig(configData);
    
    if (saved) {
      console.log('✅ Database config saved successfully');
      res.json({ 
        success: true, 
        message: 'Database configuration saved successfully',
        config: dbConfigService.getPublicConfig()
      });
    } else {
      res.status(500).json({ 
        success: false,
        error: 'Failed to save database configuration' 
      });
    }
  } catch (error) {
    console.error('❌ Save database config error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/database/test-connection', async (req, res) => {
  try {
    const { host, port, serviceName, username, password } = req.body;

    console.log('🧪 Testing database connection:', { host, port, serviceName, username });

    if (!host || !port || !serviceName || !username || !password) {
      return res.status(400).json({ 
        success: false,
        error: 'All connection fields are required for testing' 
      });
    }

    const connectionDetails = { host, port, serviceName, username, password };
    const testResult = await realOracleService.testConnection(connectionDetails);
    
    if (testResult.success) {
      console.log('✅ Database connection test successful');
      res.json({ 
        success: true, 
        message: 'Connection test successful!',
        details: testResult
      });
    } else {
      console.log('❌ Database connection test failed:', testResult.message);
      res.status(400).json({ 
        success: false,
        error: testResult.message,
        details: testResult
      });
    }
  } catch (error) {
    console.error('❌ Test connection error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// DATABASE MONITORING ROUTES - REAL-TIME
app.get('/api/database/status', async (req, res) => {
  try {
    const status = realOracleService.getConnectionStatus();
    
    if (status.isConfigured) {
      const connectionCheck = await realOracleService.checkConnection();
      
      res.json({
        success: true,
        status: connectionCheck.isConnected ? 'UP' : 'DOWN',
        timestamp: new Date(),
        isDown: !connectionCheck.isConnected,
        responseTime: connectionCheck.responseTime || 'N/A',
        connectionStatus: status,
        configured: true,
        error: connectionCheck.error || null
      });
    } else {
      res.json({
        success: true,
        status: 'NOT_CONFIGURED',
        timestamp: new Date(),
        isDown: true,
        configured: false,
        message: 'Database connection not configured'
      });
    }
  } catch (error) {
    console.error('❌ Database status error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.get('/api/database/dashboard', async (req, res) => {
  try {
    const config = dbConfigService.getConfig();
    
    if (!config.isConfigured) {
      return res.status(400).json({
        success: false,
        error: 'Database not configured'
      });
    }

    console.log('📊 Fetching real-time dashboard data...');
    const dashboardData = await realOracleService.getRealtimeDashboardData();
    
    res.json({ 
      success: true, 
      data: dashboardData,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('❌ Dashboard data error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.get('/api/database/tablespace', async (req, res) => {
  try {
    const config = dbConfigService.getConfig();
    
    if (!config.isConfigured) {
      return res.status(400).json({
        success: false,
        error: 'Database not configured'
      });
    }

    const tablespaceData = await realOracleService.getTablespaceInfo();
    console.log(`📊 Retrieved tablespace data for ${tablespaceData.length} tablespaces`);
    
    res.json({ success: true, data: tablespaceData });
  } catch (error) {
    console.error('❌ Tablespace data error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.get('/api/database/info', async (req, res) => {
  try {
    const config = dbConfigService.getConfig();
    
    if (!config.isConfigured) {
      return res.status(400).json({
        success: false,
        error: 'Database not configured'
      });
    }

    const [versionInfo, instanceInfo, sessionInfo] = await Promise.allSettled([
      realOracleService.getDatabaseVersion(),
      realOracleService.getInstanceInfo(),
      realOracleService.getSessionInfo()
    ]);

    const dbInfo = {
      version: versionInfo.status === 'fulfilled' ? versionInfo.value : { version: 'Unknown' },
      instance: instanceInfo.status === 'fulfilled' ? instanceInfo.value : null,
      sessions: sessionInfo.status === 'fulfilled' ? sessionInfo.value : null
    };
    
    console.log('📊 Retrieved database info');
    res.json({ success: true, data: dbInfo });
  } catch (error) {
    console.error('❌ Database info error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// MONITORING ROUTES
app.get('/api/monitoring/status', (req, res) => {
  try {
    const status = monitoringService.getMonitoringStatus();
    console.log('📊 Monitoring status requested');
    res.json({ success: true, status });
  } catch (error) {
    console.error('❌ Get monitoring status error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/monitoring/start', (req, res) => {
  try {
    const started = monitoringService.startMonitoring();
    
    if (started) {
      console.log('🚀 Monitoring started via API');
      res.json({ 
        success: true, 
        message: 'Database monitoring started successfully',
        status: monitoringService.getMonitoringStatus()
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: 'Failed to start monitoring (already running or database not configured)' 
      });
    }
  } catch (error) {
    console.error('❌ Start monitoring error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/monitoring/stop', (req, res) => {
  try {
    const stopped = monitoringService.stopMonitoring();
    
    if (stopped) {
      console.log('🛑 Monitoring stopped via API');
      res.json({ 
        success: true, 
        message: 'Database monitoring stopped successfully',
        status: monitoringService.getMonitoringStatus()
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: 'Monitoring was not running' 
      });
    }
  } catch (error) {
    console.error('❌ Stop monitoring error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/monitoring/force-check', async (req, res) => {
  try {
    console.log('🔍 Manual check requested');
    const result = await monitoringService.forceCheck();
    
    res.json({ 
      success: true, 
      message: 'Manual check completed',
      result: result,
      status: monitoringService.getMonitoringStatus()
    });
  } catch (error) {
    console.error('❌ Force check error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.get('/api/monitoring/history', (req, res) => {
  try {
    const history = monitoringService.getMonitoringHistory();
    console.log(`📊 Retrieved ${history.length} monitoring checks`);
    res.json({ success: true, data: history });
  } catch (error) {
    console.error('❌ Get monitoring history error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// DOWNTIME LOGS ROUTES
app.get('/api/logs/downtime', async (req, res) => {
  try {
    const logs = await logService.getDowntimeLogs();
    console.log(`📝 Retrieved ${logs.length} downtime log entries`);
    res.json({ success: true, data: logs });
  } catch (error) {
    console.error('❌ Get downtime logs error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

// EMAIL MANAGEMENT ROUTES
app.get('/api/email/list', (req, res) => {
  try {
    const emailList = emailService.getEmailList();
    console.log('📧 Email list requested');
    res.json({ success: true, data: emailList });
  } catch (error) {
    console.error('❌ Get email list error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/email/list', (req, res) => {
  try {
    const { emails } = req.body;
    
    if (!emails || !Array.isArray(emails)) {
      return res.status(400).json({ 
        success: false,
        error: 'Valid email array is required' 
      });
    }
    
    const updated = emailService.updateEmailList(emails);
    
    if (updated) {
      console.log('📧 Email list updated');
      res.json({ 
        success: true, 
        message: 'Email list updated successfully',
        data: emailService.getEmailList()
      });
    } else {
      res.status(500).json({ 
        success: false,
        error: 'Failed to update email list' 
      });
    }
  } catch (error) {
    console.error('❌ Update email list error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.post('/api/email/test', async (req, res) => {
  try {
    console.log('📧 Test email requested');
    const result = await emailService.sendTestEmail();
    
    if (result.success) {
      res.json({ 
        success: true, 
        message: 'Test email sent successfully!'
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: result.message 
      });
    }
  } catch (error) {
    console.error('❌ Send test email error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});

app.get('/api/email/config/test', async (req, res) => {
  try {
    const result = await emailService.testEmailConfiguration();
    
    if (result.success) {
      res.json({ 
        success: true, 
        message: 'Email configuration is valid'
      });
    } else {
      res.status(400).json({ 
        success: false,
        error: result.message 
      });
    }
  } catch (error) {
    console.error('❌ Test email config error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message 
    });
  }
});


// SYSTEM MONITORING ROUTES
app.get('/api/system/metrics', async (req, res) => {
  try {
    const metrics = await systemMonitoringService.getSystemMetrics();
    res.json({ success: true, data: metrics });
  } catch (error) {
    console.error('❌ System metrics error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});


// EMAIL CONFIG ROUTES
app.get('/api/email/config', (req, res) => {
  try {
    const config = emailConfigService.getPublicConfig();
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/email/config', (req, res) => {
  try {
    const { host, port, user, password } = req.body;
    
    if (!host || !user || !password) {
      return res.status(400).json({ 
        success: false,
        error: 'Host, user, and password are required' 
      });
    }

    const configData = { host, port, user, password };
    const saved = emailConfigService.updateConfig(configData);
    
    if (saved) {
      // Reinitialize email service with new config
      emailService.setupTransporter();
      res.json({ 
        success: true, 
        message: 'Email configuration saved successfully',
        config: emailConfigService.getPublicConfig()
      });
    } else {
      res.status(500).json({ success: false, error: 'Failed to save email configuration' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// EMAIL GROUP ROUTES
app.get('/api/email/groups', (req, res) => {
  try {
    const groups = emailService.getEmailGroups();
    res.json({ success: true, data: groups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/email/groups', (req, res) => {
  try {
    const group = emailService.createGroup(req.body);
    if (group) {
      res.json({ success: true, data: group });
    } else {
      res.status(500).json({ success: false, error: 'Failed to create group' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/email/groups/:id', (req, res) => {
  try {
    const group = emailService.updateGroup(req.params.id, req.body);
    if (group) {
      res.json({ success: true, data: group });
    } else {
      res.status(404).json({ success: false, error: 'Group not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/email/groups/:id', (req, res) => {
  try {
    const deleted = emailService.deleteGroup(req.params.id);
    if (deleted) {
      res.json({ success: true, message: 'Group deleted successfully' });
    } else {
      res.status(404).json({ success: false, error: 'Group not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// KUBERNETES ROUTES
app.get('/api/kubernetes/pods', async (req, res) => {
  try {
    const namespace = req.query.namespace || 'default';
    const pods = await kubernetesService.getPods(namespace);
    res.json({ success: true, data: pods });
  } catch (error) {
    console.error('❌ Get pods error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/kubernetes/pods/all', async (req, res) => {
  try {
    const pods = await kubernetesService.getAllPods();
    res.json({ success: true, data: pods });
  } catch (error) {
    console.error('❌ Get all pods error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/kubernetes/namespaces', async (req, res) => {
  try {
    const namespaces = await kubernetesService.getNamespaces();
    res.json({ success: true, data: namespaces });
  } catch (error) {
    console.error('❌ Get namespaces error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/kubernetes/nodes', async (req, res) => {
  try {
    const nodes = await kubernetesService.getNodes();
    res.json({ success: true, data: nodes });
  } catch (error) {
    console.error('❌ Get nodes error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/kubernetes/cluster-info', async (req, res) => {
  try {
    const clusterInfo = await kubernetesService.getClusterInfo();
    res.json({ success: true, data: clusterInfo });
  } catch (error) {
    console.error('❌ Get cluster info error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});


// URL MONITORING ROUTES
app.get('/api/urls', (req, res) => {
  try {
    const urls = urlMonitoringService.getAllUrls();
    res.json({ success: true, data: urls });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/urls', (req, res) => {
  try {
    const newUrl = urlMonitoringService.addUrl(req.body);
    if (newUrl) {
      res.json({ success: true, data: newUrl });
    } else {
      res.status(500).json({ success: false, error: 'Failed to add URL' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/urls/:id', (req, res) => {
  try {
    const updatedUrl = urlMonitoringService.updateUrl(req.params.id, req.body);
    if (updatedUrl) {
      res.json({ success: true, data: updatedUrl });
    } else {
      res.status(404).json({ success: false, error: 'URL not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/urls/:id', (req, res) => {
  try {
    const deleted = urlMonitoringService.deleteUrl(req.params.id);
    if (deleted) {
      res.json({ success: true, message: 'URL deleted successfully' });
    } else {
      res.status(404).json({ success: false, error: 'URL not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/urls/statuses', (req, res) => {
  try {
    const statuses = urlMonitoringService.getUrlStatuses();
    res.json({ success: true, data: statuses });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/urls/stats', (req, res) => {
  try {
    const stats = urlMonitoringService.getMonitoringStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/urls/check/:id', async (req, res) => {
  try {
    const urls = urlMonitoringService.getAllUrls();
    const url = urls.find(u => u.id === parseInt(req.params.id));
    
    if (!url) {
      return res.status(404).json({ success: false, error: 'URL not found' });
    }
    
    const result = await urlMonitoringService.checkUrl(url);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});


// KUBERNETES CONFIG ROUTES
app.get('/api/kubernetes/config', (req, res) => {
  try {
    const config = kubernetesConfigService.getPublicConfig();
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/kubernetes/config', (req, res) => {
  try {
    const { kubeconfigPath } = req.body;
    
    console.log('📝 Received kubeconfigPath:', kubeconfigPath);
    
    // Allow empty path to clear configuration
    if (kubeconfigPath && kubeconfigPath.trim() !== '') {
      console.log('🔍 Validating non-empty path...');
      const validation = kubernetesConfigService.validateConfigPath(kubeconfigPath);
      if (!validation.valid) {
        console.log('❌ Validation failed:', validation.error);
        return res.status(400).json({ 
          success: false,
          error: validation.error 
        });
      }
    } else {
      console.log('✅ Empty path - clearing configuration');
    }

    const configData = { kubeconfigPath: kubeconfigPath || '' };
    const saved = kubernetesConfigService.updateConfig(configData);
    
    if (saved) {
      console.log('✅ Config saved successfully');
      res.json({ 
        success: true, 
        message: 'Kubernetes configuration saved successfully',
        config: kubernetesConfigService.getPublicConfig()
      });
    } else {
      console.log('❌ Failed to save config');
      res.status(500).json({ success: false, error: 'Failed to save Kubernetes configuration' });
    }
  } catch (error) {
    console.error('❌ Route error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/kubernetes/config/test', async (req, res) => {
  try {
    const { kubeconfigPath } = req.body;
    
    if (!kubeconfigPath) {
      return res.status(400).json({ 
        success: false,
        error: 'Kubeconfig path is required for testing' 
      });
    }

    // Create a temporary config to test without saving
    const tempConfig = { kubeconfigPath, isConfigured: true };
    kubernetesConfigService.saveConfig(tempConfig);
    
    // Reload and test
    kubernetesService.setupKubernetesClient();
    const testResult = await kubernetesService.testConnection();
    
    res.json({ 
      success: testResult.success, 
      message: testResult.message || testResult.error,
      details: testResult
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// THRESHOLD ROUTES
app.get('/api/thresholds/db-size', (req, res) => {
  try {
    const threshold = thresholdService.getDbSizeThreshold();
    res.json({ success: true, data: threshold });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/thresholds/db-size', (req, res) => {
  try {
    const saved = thresholdService.updateDbSizeThreshold(req.body);
    if (saved) {
      res.json({ success: true, message: 'Threshold settings saved' });
    } else {
      res.status(500).json({ success: false, error: 'Failed to save' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});


// SCRIPT MANAGEMENT ROUTES
app.get('/api/scripts', (req, res) => {
  try {
    const scripts = scriptService.getAllScripts();
    console.log(`📜 Retrieved ${scripts.length} scripts`);
    res.json({ success: true, data: scripts });
  } catch (error) {
    console.error('❌ Get scripts error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/scripts', (req, res) => {
  try {
    const { name, description, scriptPath, arguments: args } = req.body;
    
    console.log('📝 Creating script:', { name, scriptPath, args });
    
    if (!name || !scriptPath) {
      return res.status(400).json({ 
        success: false,
        error: 'Name and script path are required' 
      });
    }

    // Validate the script path
    const validation = scriptService.validateScriptPath(scriptPath);
    if (!validation.valid) {
      console.log('❌ Script validation failed:', validation.error);
      return res.status(400).json({ 
        success: false,
        error: `Script validation failed: ${validation.error}` 
      });
    }

    const newScript = scriptService.addScript({
      name,
      description,
      scriptPath,
      arguments: args
    });
    
    if (newScript) {
      console.log('✅ Script created successfully:', newScript.name);
      res.json({ success: true, data: newScript });
    } else {
      res.status(500).json({ success: false, error: 'Failed to create script' });
    }
  } catch (error) {
    console.error('❌ Create script error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/scripts/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, scriptPath, arguments: args } = req.body;
    
    console.log('🔄 Updating script:', id, { name, scriptPath, args });
    
    if (!name || !scriptPath) {
      return res.status(400).json({ 
        success: false,
        error: 'Name and script path are required' 
      });
    }

    // Validate the script path
    const validation = scriptService.validateScriptPath(scriptPath);
    if (!validation.valid) {
      console.log('❌ Script validation failed:', validation.error);
      return res.status(400).json({ 
        success: false,
        error: `Script validation failed: ${validation.error}` 
      });
    }

    const updatedScript = scriptService.updateScript(id, {
      name,
      description,
      scriptPath,
      arguments: args
    });
    
    if (updatedScript) {
      console.log('✅ Script updated successfully:', updatedScript.name);
      res.json({ success: true, data: updatedScript });
    } else {
      res.status(404).json({ success: false, error: 'Script not found' });
    }
  } catch (error) {
    console.error('❌ Update script error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/scripts/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    console.log('🗑️ Deleting script:', id);
    
    const deleted = scriptService.deleteScript(id);
    
    if (deleted) {
      console.log('✅ Script deleted successfully');
      res.json({ success: true, message: 'Script deleted successfully' });
    } else {
      res.status(404).json({ success: false, error: 'Script not found' });
    }
  } catch (error) {
    console.error('❌ Delete script error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/scripts/:id/run', async (req, res) => {
  try {
    const { id } = req.params;
    
    console.log('🏃 Running script:', id);
    
    const result = await scriptService.runScript(id);
    
    if (result.success) {
      console.log('✅ Script executed successfully');
      res.json({ 
        success: true, 
        output: result.output,
        executedAt: result.executedAt
      });
    } else {
      console.log('❌ Script execution failed');
      res.status(400).json({ 
        success: false,
        error: result.error,
        output: result.output,
        executedAt: result.executedAt
      });
    }
  } catch (error) {
    console.error('❌ Run script error:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

app.get('/api/scripts/:id/history', (req, res) => {
  try {
    const { id } = req.params;
    const history = scriptService.getScriptExecutionHistory(id);
    
    if (history) {
      res.json({ success: true, data: history });
    } else {
      res.status(404).json({ success: false, error: 'Script not found' });
    }
  } catch (error) {
    console.error('❌ Get script history error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/scripts/validate-path', (req, res) => {
  try {
    const { scriptPath } = req.body;
    
    if (!scriptPath) {
      return res.status(400).json({ 
        success: false,
        error: 'Script path is required' 
      });
    }

    const validation = scriptService.validateScriptPath(scriptPath);
    res.json({ success: validation.valid, ...validation });
  } catch (error) {
    console.error('❌ Validate script path error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});



// Error handling middleware
app.use((err, req, res, next) => {
  console.error('💥 Unhandled error:', err);
  res.status(500).json({ 
    success: false,
    error: 'Internal server error',
    message: err.message
  });
});

// Handle 404
app.use((req, res) => {
  res.status(404).json({ 
    success: false,
    error: 'Route not found' 
  });
});


// Auto-start URL monitoring when server starts
setTimeout(() => {
  console.log('🌐 Auto-starting URL monitoring...');
  const started = urlMonitoringService.startAllMonitoring();
  console.log(`✅ Started monitoring ${started} URLs`);
}, 3000);


// Auto-start monitoring if database is configured
setTimeout(() => {
  const config = dbConfigService.getConfig();
  if (config.isConfigured) {
    console.log('🚀 Auto-starting database monitoring...');
    const started = monitoringService.startMonitoring();
    if (started) {
      console.log('✅ Database monitoring started automatically');
    } else {
      console.log('❌ Failed to auto-start monitoring');
    }
  } else {
    console.log('⚠️ Database not configured - monitoring not started');
  }
}, 2000); // Wait 2 seconds for services to initialize

// Start server
app.listen(PORT, () => {
  console.log(`🚀 UPTIME WATCHDOG by Tsunami Solutions running on http://localhost:${PORT}`);
  console.log(`📊 Real Oracle database monitoring enabled`);
  console.log(`👤 User count: ${userService.getUserCount()}`);
  console.log(`🔗 Database configured: ${dbConfigService.getConfig().isConfigured}`);
  console.log('✅ Oracle Monitor Backend with Real DB Connection Started!');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down gracefully...');
  await realOracleService.disconnect();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await realOracleService.disconnect();
  process.exit(0);
});